class Pipline1():
    def __init__(self) -> None:
        pass