
class SlidingWindowObject():

    def __init__(self, Top, Bottom, Left, Right):
        self.Top = Top
        self.Bottom = Bottom
        self.Left = Left
        self.Right = Right